"""Program that uses EAST text detection and Tesseract OCR to 
   find and recognise text / numbers on road signs.
   Uses "confidence" percentages to determine how muhc 
   Returns the original image and adds a rectangle around 
   detected numbers adds the recognised text above the rectange
   and prints the detected OCR text to the terminal"""

"""USAGE:
   - You must install all necessary packages and donwload 
   and install tesseract OCR.
   - Add this python script to the tesseact OCR folder.
   - Then add the Road Signs image folder to the tesseract
   folder once installed.
   - Inside the tesseract folder open the command line or PowerShell
   and type 'python imageProcessingProject.py '--imageName 'InputFileName.jpg' '
	e.g 'python imageProcessingProject.py --imageName Road-sign/road-sign2' """
   
# import necessary packages
from imutils.object_detection import non_max_suppression
import numpy as np
import pytesseract
import argparse
import cv2
import argparse

# use argparse library to get image name from command line
ap = argparse.ArgumentParser()
ap.add_argument("-n", "--imageName", required=True,
	help="name of the image")
args = vars(ap.parse_args())

#takes input image from command line argument and makes a copy for later use
img = cv2.imread(args['imageName'])
img_copy = img.copy()

# convert the image to greyscale and add blur. This makes it easier to detect circles.
Grey = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
Grey = cv2.medianBlur(Grey, 5)

# gets the number of rows which helps circle detection so multiple circles wont overlap
rows = Grey.shape[0]

# detects circles in the image (HoughCircles)
circles = cv2.HoughCircles(Grey, cv2.HOUGH_GRADIENT, 1, rows / 8, 
param1=450, param2=30, 
minRadius=5, maxRadius=100)
circles = np.uint16(np.around(circles))

for i in circles[0]:
		center = (i[0], i[1])
		radius = i[2]
		i = i.astype(int)
		crop = img_copy[i[1]-i[2]:i[1]+i[2], i[0]-i[2]:i[0]+i[2]]
		cv2.circle(img,center,radius + 5, (0,255,0), 2)

def decode_predictions(scores, geometry):
    # get number of rows and columns from scores
    # initialize rectangles and corresponding confidence scores
	(numberOfRows, numberOfColumns) = scores.shape[2:4]
	rects = []
	confidences = []

	# loop over rows
	for y in range(0, numberOfRows):
        # extract scores (probabilities) and geometrical data
        # for bounding box
        # coordinates surrounding any text
		scoresData = scores[0, 0, y]
		xData0 = geometry[0, 0, y]
		xData1 = geometry[0, 1, y]
		xData2 = geometry[0, 2, y]
		xData3 = geometry[0, 3, y]
		anglesData = geometry[0, 4, y]

		# loop over columns
		for x in range(0, numberOfColumns):
            # if score does not have sufficient probability, ignore

            # compute offset factor as resulting feature
            # result maps = 4x smaller
			(offsetX, offsetY) = (x * 4.0, y * 4.0)

            # extract rotation angle for prediction
            # compute sin and cosine
			angle = anglesData[x]
			cos = np.cos(angle)
			sin = np.sin(angle)

            # use geometry volume to derive width/height of box
			h = xData0[x] + xData2[x]
			w = xData1[x] + xData3[x]

            # compute both starting and ending (x, y)-coordinates for box
			endX = int(offsetX + (cos * xData1[x]) + (sin * xData2[x]))
			endY = int(offsetY - (sin * xData1[x]) + (cos * xData2[x]))
			startX = int(endX - w)
			startY = int(endY - h)

            # add text box coordinates and probability score to lists
			rects.append((startX, startY, endX, endY))
			confidences.append(scoresData[x])

    # return tuple of text boxes and associated confidences
	return (rects, confidences)

# load cropped image and grab image dimensions
image = crop.copy()
orig = image.copy()
(origH, origW) = image.shape[:2]

(newW, newH) = (320,320)
rW = origW / float(newW)
rH = origH / float(newH)

# resize image and grab new image dimensions
image = cv2.resize(image, (newW, newH))
(H, W) = image.shape[:2]

# define 2 output layer names for EAST detector model
# first = output probabilities
# second = derive text box coordinates of text
layerNames = [
	"feature_fusion/Conv_7/Sigmoid",
	"feature_fusion/concat_3"]

# load pre-trained EAST text detector
print("\nUsing EAST to detect text, Please Wait.")
net = cv2.dnn.readNet("frozen_east_text_detection.pb")

# construct a blob from image
# perform a forward pass of model
# obtain 2 output layer sets
blob = cv2.dnn.blobFromImage(image, 1.0, (W, H),
	(123.68, 116.78, 103.94), swapRB=True, crop=False)
net.setInput(blob)
(scores, geometry) = net.forward(layerNames)

# decode predictions
# apply non-maxima suppression
# suppress weak/overlapping text boxes
(rects, confidences) = decode_predictions(scores, geometry)
boxes = non_max_suppression(np.array(rects), probs=confidences)

# initialize results list
results = []

# loop over text boxes
for (startX, startY, endX, endY) in boxes:
    # scale text box coordinates - respective ratios
	startX = int(startX * rW)
	startY = int(startY * rH)
	endX = int(endX * rW)
	endY = int(endY * rH)

    # to obtain better OCR of the text we can apply
    # some padding surrounding the text box

    # computing deltas in x and y directions
	dX = int((endX - startX) * 1)
	dY = int((endY - startY) * 1)

    # apply padding to each side of the text boxes
	startX = max(0, startX - dX)
	startY = max(0, startY - dY)
	endX = min(origW, endX + (dX * 2))
	endY = min(origH, endY + (dY * 2))

	# extract actual padded ROI
	roi = orig[startY:endY, startX:endX]

    # to apply Tesseract v4 to OCR text we must give:
    # (1) a language
    # (2) an OEM flag of 1, to use the LSTM neural net model for OCR
    # (3) an OEM value, 7 which implies that we are
    # treating ROI as a single line of text
	config = ("-l eng --oem 1 --psm 7")
	text = pytesseract.image_to_string(roi, config=config)

    # add text box coordinates and OCR'd text to the list of results
	results.append(((startX, startY, endX, endY), text))

# sort results text box coordinates from top to bottom
results = sorted(results, key=lambda r:r[0][1])

# some error checking to stop program detecting numbers as letters/words
if(text):
	if(text[0] == '('):
		text = text[1:]
	if(text[len(text)-1] == ')'):
		text = text[0:-1]
	if(text[0] == ','):
		text = text[1:0]
	if(text[len(text)-1] == ','):
		text = text[0:-1]
		
	for x in range(len(text)):
		if(text[x] == 'S'):
			text[x] = '5'
		if(text[x] == 'O'):
			text[x] = '0'

	
	print("Road Sign Detected!")
	print("{}\n".format('Speed Limit is: ' + text))

	# removes non-ASCII values from the detected text
	text = "".join([c if ord(c) < 128 else "" for c in text]).strip("")

	# uses original image after working on cropped image
	output = img.copy()

	# shows speed limit result on original image
	cv2.putText(output, text, (startX, endY + 20),
		cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0,255,0), 3)

	# show output image and original image beside each other
	comparison = np.hstack((img_copy,output))
	cv2.imshow("Speed Limit Detection", comparison)
	cv2.waitKey(0)
else:
	print("No road sign detected")